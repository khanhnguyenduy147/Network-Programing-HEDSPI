import numpy as np

def gen_data_one_hot(M, datasize):
    sourcedata = np.random.randint(M, size= datasize)
    data = []
    for i in sourcedata:
        temp = np.zeros(M)
        temp[i] = 1
        data.append(temp)
    data = np.array(data)
    return data, sourcedata


def reverse_data_from_onehot(data):
    data_origin = []
    for i in data:
        for k in range(0,len(i)):
            if i[k] == 1:
                data_origin.append(k)
                break
    data_origin = np.array(data_origin)
    return data_origin

'''Test func
x,src = gen_data_one_hot(6, 4)
print(src)
print(x)
print(reverse_data_from_onehot(x))
'''
