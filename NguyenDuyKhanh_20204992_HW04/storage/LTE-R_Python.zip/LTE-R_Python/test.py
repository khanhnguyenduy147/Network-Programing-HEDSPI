import tensorflow as tf
import numpy as np
import genData

#------------Parameter for system-------------------
N = 1024   # Number of subcarrier
m = 8     # Bit per symbol
M = 2**m     # Size of one hot symbol
R = m/N
SNR_train_dB = np.arange(0,20,5)
B = 10e6

# Parameter for MonteCarlo
rho = np.array([1, 0.1345, 0.1357])   #discrete multi-path channel profile
N_P = len(rho)
number_of_summations = 50
fD_max = 1024
u = np.random.rand(N_P, number_of_summations)

# Parameter for AE_LTE-R
Nofdm = 100
snr_train = 10**(SNR_train_dB/10.0)
noise_std = np.sqrt(1/(2*R*snr_train))

x,y = genData.gen_data_one_hot(4,6)

print(x)
print(np.argmax(x, axis=1))


